package com.aetherium;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod(modid = AetheriumMod.MODID, name = AetheriumMod.NAME, version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
public class AetheriumMod {

    public static final String MODID = "aetherium";
    public static final String NAME = "Aetherium";

    public static final CreativeTabs TAB = new CreativeTabs("aetherium") {
        @Override
        @SideOnly(Side.CLIENT)
        public ItemStack getTabIconItem() {
            return new ItemStack(ModItems.GEM);
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // Cevher uretimi (Overworld)
        GameRegistry.registerWorldGenerator(new OreGenerator(), 0);
    }
}
