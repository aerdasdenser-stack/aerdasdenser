package com.aetherium;

import java.util.Random;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraftforge.fml.common.IWorldGenerator;

public class OreGenerator implements IWorldGenerator {

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world,
                         IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.provider.getDimension() != 0) {
            return; // sadece Overworld
        }
        WorldGenMinable gen = new WorldGenMinable(ModBlocks.ORE.getDefaultState(), 6);
        // Chunk basina 4 damar, Y 4-30 arasi (elmasa yakin derinlik)
        for (int i = 0; i < 4; i++) {
            int x = chunkX * 16 + random.nextInt(16);
            int y = 4 + random.nextInt(27);
            int z = chunkZ * 16 + random.nextInt(16);
            gen.generate(world, random, new BlockPos(x, y, z));
        }
    }
}
