package com.aetherium;

import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod.EventBusSubscriber(modid = AetheriumMod.MODID)
public class ModItems {

    // Elmas: seviye 3, 1561 dayaniklilik, hiz 8, hasar 3
    // Aetherium: seviye 4, 3200 dayaniklilik, hiz 10, hasar 5
    public static final Item.ToolMaterial TOOL_MATERIAL =
            EnumHelper.addToolMaterial("AETHERIUM", 4, 3200, 10.0F, 5.0F, 22);

    // Elmas zirh: dayaniklilik carpani 33, {3,6,8,3}, tokluk 2
    // Aetherium: 45, {4,7,9,4}, tokluk 3
    public static final ItemArmor.ArmorMaterial ARMOR_MATERIAL =
            EnumHelper.addArmorMaterial("AETHERIUM", "aetherium:aetherium", 45,
                    new int[]{4, 7, 9, 4}, 22, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 3.0F);

    public static final Item GEM = named(new Item(), "aetherium_gem");

    public static final Item SWORD = named(new ItemSword(TOOL_MATERIAL), "aetherium_sword");
    public static final Item PICKAXE = named(new AetheriumPickaxe(), "aetherium_pickaxe");
    public static final Item AXE = named(new AetheriumAxe(), "aetherium_axe");
    public static final Item SHOVEL = named(new ItemSpade(TOOL_MATERIAL), "aetherium_shovel");
    public static final Item HOE = named(new ItemHoe(TOOL_MATERIAL), "aetherium_hoe");

    public static final Item HELMET = named(new ItemArmor(ARMOR_MATERIAL, 0, EntityEquipmentSlot.HEAD), "aetherium_helmet");
    public static final Item CHESTPLATE = named(new ItemArmor(ARMOR_MATERIAL, 0, EntityEquipmentSlot.CHEST), "aetherium_chestplate");
    public static final Item LEGGINGS = named(new ItemArmor(ARMOR_MATERIAL, 0, EntityEquipmentSlot.LEGS), "aetherium_leggings");
    public static final Item BOOTS = named(new ItemArmor(ARMOR_MATERIAL, 0, EntityEquipmentSlot.FEET), "aetherium_boots");

    public static final Item[] ALL = {
            GEM, SWORD, PICKAXE, AXE, SHOVEL, HOE, HELMET, CHESTPLATE, LEGGINGS, BOOTS
    };

    static {
        TOOL_MATERIAL.setRepairItem(new ItemStack(GEM));
        ARMOR_MATERIAL.setRepairItem(new ItemStack(GEM));
    }

    private static Item named(Item item, String name) {
        item.setRegistryName(AetheriumMod.MODID, name);
        item.setUnlocalizedName(AetheriumMod.MODID + "." + name);
        item.setCreativeTab(AetheriumMod.TAB);
        return item;
    }

    // ItemPickaxe / ItemAxe kuruculari protected oldugu icin ince alt siniflar
    public static class AetheriumPickaxe extends ItemPickaxe {
        public AetheriumPickaxe() {
            super(TOOL_MATERIAL);
        }
    }

    public static class AetheriumAxe extends ItemAxe {
        public AetheriumAxe() {
            // Ozel malzeme sirasi dizi disina ciktigi icin hasar/hiz elle verilir
            super(TOOL_MATERIAL, 5.0F, -3.0F);
        }
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(ALL);
    }

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void registerModels(ModelRegistryEvent event) {
        for (Item item : ALL) {
            ModelLoader.setCustomModelResourceLocation(item, 0,
                    new ModelResourceLocation(item.getRegistryName(), "inventory"));
        }
    }
}
