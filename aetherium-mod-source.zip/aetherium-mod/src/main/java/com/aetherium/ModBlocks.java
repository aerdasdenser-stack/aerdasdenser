package com.aetherium;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod.EventBusSubscriber(modid = AetheriumMod.MODID)
public class ModBlocks {

    public static final Block ORE = new BlockAetheriumOre();
    public static final Block BLOCK = createStorageBlock();

    private static Block createStorageBlock() {
        Block b = new Block(Material.IRON);
        b.setRegistryName(AetheriumMod.MODID, "aetherium_block");
        b.setUnlocalizedName(AetheriumMod.MODID + ".aetherium_block");
        b.setCreativeTab(AetheriumMod.TAB);
        b.setHardness(6.0F);
        b.setResistance(30.0F);
        b.setHarvestLevel("pickaxe", 2);
        return b;
    }

    public static class BlockAetheriumOre extends Block {
        public BlockAetheriumOre() {
            super(Material.ROCK);
            setRegistryName(AetheriumMod.MODID, "aetherium_ore");
            setUnlocalizedName(AetheriumMod.MODID + ".aetherium_ore");
            setCreativeTab(AetheriumMod.TAB);
            setHardness(4.0F);
            setResistance(15.0F);
            setHarvestLevel("pickaxe", 2); // demir kazma yeter
        }

        @Override
        public Item getItemDropped(IBlockState state, Random rand, int fortune) {
            return ModItems.GEM;
        }

        @Override
        public int quantityDropped(Random random) {
            return 1 + random.nextInt(2); // 1-2 adet, sans (fortune) ile artar
        }

        @Override
        public int getExpDrop(IBlockState state, IBlockAccess world, BlockPos pos, int fortune) {
            Random rand = world instanceof World ? ((World) world).rand : new Random();
            return MathHelper.getInt(rand, 3, 7);
        }
    }

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(ORE, BLOCK);
    }

    @SubscribeEvent
    public static void registerItemBlocks(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(
                new ItemBlock(ORE).setRegistryName(ORE.getRegistryName()),
                new ItemBlock(BLOCK).setRegistryName(BLOCK.getRegistryName()));
    }

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void registerModels(ModelRegistryEvent event) {
        for (Block b : new Block[]{ORE, BLOCK}) {
            ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(b), 0,
                    new ModelResourceLocation(b.getRegistryName(), "inventory"));
        }
    }
}
