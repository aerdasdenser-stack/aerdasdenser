package com.aetherium;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Deneme fikri: 4 parca Aetherium zirhi giyen oyuncu "set bonusu" kazanir
 * (Hiz I + Gece Gorusu + Yenilenme icin kisa sureli Direnc).
 */
@Mod.EventBusSubscriber(modid = AetheriumMod.MODID)
public class ArmorSetHandler {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.world.isRemote) {
            return;
        }
        EntityPlayer p = event.player;
        if (p.ticksExisted % 40 != 0 || !hasFullSet(p)) {
            return;
        }
        p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 100, 0, true, false));
        p.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 320, 0, true, false));
        p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 100, 0, true, false));
    }

    private static boolean hasFullSet(EntityPlayer p) {
        return p.getItemStackFromSlot(EntityEquipmentSlot.HEAD).getItem() == ModItems.HELMET
                && p.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() == ModItems.CHESTPLATE
                && p.getItemStackFromSlot(EntityEquipmentSlot.LEGS).getItem() == ModItems.LEGGINGS
                && p.getItemStackFromSlot(EntityEquipmentSlot.FEET).getItem() == ModItems.BOOTS;
    }
}
