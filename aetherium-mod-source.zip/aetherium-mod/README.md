# Aetherium (Minecraft Java 1.12.2 / Forge 14.23.5.2860)

Elmastan guclu yeni bir maden: **Aetherium**.

## Icerik
- **Aetherium Madeni** (Overworld, Y 4-30, chunk basina 4 damar). Demir kazma ile kirilir, 1-2 mucevher dusurur (Fortune ile artar) + XP.
- **Aetherium Mucevheri**, **Aetherium Blok** (9 mucevher <-> 1 blok)
- Aletler: kilic, kazma, balta, kurek, capa
- Zirh: kask, gogusluk, pantolon, bot
- Tarifler elmasla ayni sekilde (mucevher + cubuk)

## Elmasla karsilastirma
| | Elmas | Aetherium |
|---|---|---|
| Kazma seviyesi | 3 | 4 |
| Alet dayanikliligi | 1561 | 3200 |
| Kazma hizi | 8.0 | 10.0 |
| Ek hasar | 3.0 | 5.0 |
| Zirh puani (toplam) | 20 | 24 |
| Zirh tokluk (her parca) | 2 | 3 |
| Zirh dayaniklilik carpani | 33 | 45 |

## Deneme fikri: set bonusu
4 parca Aetherium zirhi giyince Hiz I + Gece Gorusu + Direnc I kazanirsin.

## Jar olarak derleme (Java 8 gerekir)
1. https://files.minecraftforge.net adresinden 1.12.2 -> 14.23.5.2860 **MDK** indir ve ac.
2. Bu klasordeki `src` klasorunu MDK'nin icindeki `src` ile degistir, `build.gradle` dosyasini da bununla degistir.
3. Komut satirinda: `gradlew build` (Windows) veya `./gradlew build`
4. Jar su klasorde olusur: `build/libs/aetherium-1.12.2-1.0.jar`
5. Jar'i `.minecraft/mods` klasorune at (Forge 1.12.2 yuklu olmali).
